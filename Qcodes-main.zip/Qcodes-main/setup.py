"""
This file only exists as a fallback for older versions of pip/setuptools
All configuration is done in pyproject.toml
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
