# left here for backwards compatibility
# but not part of the api officially
from qcodes.parameters import Function

__all__ = ["Function"]
