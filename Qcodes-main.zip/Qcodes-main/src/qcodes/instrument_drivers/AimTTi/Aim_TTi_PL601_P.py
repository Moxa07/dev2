from ._AimTTi_PL_P import AimTTi


class AimTTiPL601(AimTTi):
    """
    This is the QCoDeS driver for the Aim TTi PL601-P series power supply.
    """

    pass
