from ._AimTTi_PL_P import AimTTi


class AimTTiPL155P(AimTTi):
    """
    This is the QCoDeS driver for the Aim TTi PL155-P series power supply.
    """

    pass
