from ._Keithley_2600 import Keithley2600


class Keithley2636B(Keithley2600):
    """
    QCoDeS driver for the Keithley 2636B Source-Meter
    """

    pass
