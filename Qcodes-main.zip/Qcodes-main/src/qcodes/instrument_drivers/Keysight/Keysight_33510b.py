from .KeysightAgilent_33XXX import Keysight33xxx


class Keysight33510B(Keysight33xxx):
    """
    QCoDeS driver for the Keysight 33510B waveform generator.
    """
