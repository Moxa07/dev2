from .KeysightAgilent_33XXX import Keysight33xxx


class Keysight33210A(Keysight33xxx):
    """
    QCoDeS driver for the Keysight 33210A waveform generator.
    """
