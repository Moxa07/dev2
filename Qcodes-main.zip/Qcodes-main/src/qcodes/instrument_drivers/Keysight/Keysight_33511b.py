from .KeysightAgilent_33XXX import Keysight33xxx


class Keysight33511B(Keysight33xxx):
    """
    QCoDeS driver for the Keysight 33511B waveform generator.
    """
