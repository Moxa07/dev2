from .KeysightAgilent_33XXX import Keysight33xxx


class Keysight33622A(Keysight33xxx):
    """
    QCoDeS driver for the Keysight 33622A waveform generator.
    """
