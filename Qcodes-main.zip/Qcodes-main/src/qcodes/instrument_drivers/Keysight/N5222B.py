from .Keysight_N5222B import KeysightN5222B


class N5222B(KeysightN5222B):
    """
    Alias for backwards compatibility

    """
