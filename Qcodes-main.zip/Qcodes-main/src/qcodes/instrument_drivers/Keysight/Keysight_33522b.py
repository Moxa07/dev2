from .KeysightAgilent_33XXX import Keysight33xxx


class Keysight33522B(Keysight33xxx):
    """
    QCoDeS driver for the Keysight 33522B waveform generator.
    """
