from .Keysight_N5245A import KeysightN5245A


class N5245A(KeysightN5245A):
    """
    Alias for backwards compatibility
    """
