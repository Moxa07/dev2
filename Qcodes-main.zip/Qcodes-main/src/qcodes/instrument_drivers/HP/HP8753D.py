"""
Module left for backwards compatibility. Will be deprecated and removed eventually.
"""

from .HP_8753D import HP8753D
