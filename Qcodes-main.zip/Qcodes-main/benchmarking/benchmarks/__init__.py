"""
This module contains benchmarks for QCoDeS. These benchmarks shall be executed
by the `asv` (airspeed velocity) package.
"""
