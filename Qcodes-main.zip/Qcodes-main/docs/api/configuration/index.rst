.. _config_api :

qcodes.configuration
====================

.. automodule:: qcodes.configuration
    :autosummary:

qcodes default configuration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The following table contains the default configuration of qcodes.

.. jsonschema:: ../../../src/qcodes/configuration/qcodesrc_schema.json
