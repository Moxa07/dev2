.. _parameter_api :

qcodes.parameters
=================

.. automodule:: qcodes.parameters
    :autosummary:
