.. _Community :

Community Guide
===============

This is the guide for you, the developer that wants to maintain/expand QCoDes.

.. toctree::
   :maxdepth: 2

   install
   contributing
   related_projects
   objects
