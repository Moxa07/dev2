.. _installcom:


Source Code
-----------
The source lives on  https://github.com/QCoDeS .

Refer to  https://github.com/QCoDeS/Qcodes#install
for how to on install from source.
