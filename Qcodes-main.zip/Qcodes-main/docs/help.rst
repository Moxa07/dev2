.. _help:

Get Help
========

Welcome to the QCoDeS community!
We would love to have you join us and share your ideas.

Please help us spread the word and grow the community!

For more info  on how to contribute, ask questions check out the :ref:`contributing` section.
