.. _dataset:

DataSet
=======

.. toctree::
   :maxdepth: 2

   introduction
   spec
   dataset_design
   interdependentparams
