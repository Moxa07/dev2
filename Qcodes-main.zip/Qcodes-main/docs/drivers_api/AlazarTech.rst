.. _Alazar_api :

Alazar Tech Drivers
===================

.. automodule:: qcodes.instrument_drivers.AlazarTech
    :autosummary:
    :no-inherited-members:
