.. _zhinst_api :

Zurich Instruments Drivers
==========================

The module ``qcodes.instrument_drivers.zurich_instruments`` contains aliases for
drivers implemented in the `zhinst-qcodes`_ pacakge. Please refer to the documentation
of `zhinst-qcodes`_ for more information.

.. _zhinst-qcodes: https://docs.zhinst.com/zhinst-qcodes/en/latest/
