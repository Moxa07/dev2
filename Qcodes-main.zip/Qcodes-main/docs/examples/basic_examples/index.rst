Basic examples
--------------

.. toctree::
    :glob:

    *
