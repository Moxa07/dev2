Plotting
--------

.. toctree::
    :glob:

    *
