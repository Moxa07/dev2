These notebooks provide some examples of how to tweak and customize the QCoDeS parameters to achieve different ends.
